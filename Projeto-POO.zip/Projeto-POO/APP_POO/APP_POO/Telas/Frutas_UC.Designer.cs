﻿namespace APP_POO.Telas
{
    partial class Frutas_UC
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            Panel_Maca = new Panel();
            button3 = new Button();
            label7 = new Label();
            button2 = new Button();
            button1 = new Button();
            label5 = new Label();
            label6 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            Btn_Voltar = new Button();
            panel2 = new Panel();
            Panel_Banana = new Panel();
            button4 = new Button();
            label8 = new Label();
            button5 = new Button();
            button6 = new Button();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            panel3 = new Panel();
            Panel_Morango = new Panel();
            button8 = new Button();
            label14 = new Label();
            button9 = new Button();
            button10 = new Button();
            label15 = new Label();
            label16 = new Label();
            label17 = new Label();
            label18 = new Label();
            label19 = new Label();
            panel4 = new Panel();
            Panel_Abacaxi = new Panel();
            button12 = new Button();
            label20 = new Label();
            button13 = new Button();
            button14 = new Button();
            label21 = new Label();
            label22 = new Label();
            label23 = new Label();
            label24 = new Label();
            label25 = new Label();
            panel5 = new Panel();
            Panel_Laranja = new Panel();
            button16 = new Button();
            Label_LaranjaPreco = new Label();
            Btn_AumentarLaranja = new Button();
            Btn_DiminuirLaranja = new Button();
            label27 = new Label();
            label28 = new Label();
            label29 = new Label();
            label30 = new Label();
            label31 = new Label();
            panel6 = new Panel();
            Panel_Uva = new Panel();
            button20 = new Button();
            label32 = new Label();
            button21 = new Button();
            button22 = new Button();
            label33 = new Label();
            label34 = new Label();
            label35 = new Label();
            label36 = new Label();
            label37 = new Label();
            panel7 = new Panel();
            label1 = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            panel6.SuspendLayout();
            panel7.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(192, 255, 192);
            panel1.Controls.Add(Panel_Maca);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Dock = DockStyle.Bottom;
            panel1.Location = new Point(0, 780);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(545, 123);
            panel1.TabIndex = 12;
            // 
            // Panel_Maca
            // 
            Panel_Maca.Location = new Point(14, 49);
            Panel_Maca.Name = "Panel_Maca";
            Panel_Maca.Size = new Size(67, 67);
            Panel_Maca.TabIndex = 14;
            // 
            // button3
            // 
            button3.Font = new Font("Montserrat SemiBold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.Location = new Point(479, 33);
            button3.Margin = new Padding(3, 4, 3, 4);
            button3.Name = "button3";
            button3.Size = new Size(72, 53);
            button3.TabIndex = 16;
            button3.Text = "ADD";
            button3.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Montserrat SemiBold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(403, 49);
            label7.Name = "label7";
            label7.Size = new Size(21, 24);
            label7.TabIndex = 15;
            label7.Text = "0";
            // 
            // button2
            // 
            button2.Font = new Font("Montserrat SemiBold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(431, 45);
            button2.Margin = new Padding(3, 4, 3, 4);
            button2.Name = "button2";
            button2.Size = new Size(26, 31);
            button2.TabIndex = 14;
            button2.Text = "+";
            button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Font = new Font("Montserrat SemiBold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(371, 45);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(26, 31);
            button1.TabIndex = 13;
            button1.Text = "-";
            button1.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Montserrat SemiBold", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(227, 49);
            label5.Name = "label5";
            label5.Size = new Size(118, 37);
            label5.TabIndex = 5;
            label5.Text = "R$ 2,50";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Montserrat SemiBold", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(226, 13);
            label6.Name = "label6";
            label6.Size = new Size(120, 21);
            label6.TabIndex = 4;
            label6.Text = "Preço Unitário";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Montserrat SemiBold", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(121, 49);
            label4.Name = "label4";
            label4.Size = new Size(51, 37);
            label4.TabIndex = 3;
            label4.Text = "50";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Montserrat SemiBold", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(102, 13);
            label3.Name = "label3";
            label3.Size = new Size(100, 21);
            label3.TabIndex = 2;
            label3.Text = "Quantidade";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Montserrat SemiBold", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(23, 13);
            label2.Name = "label2";
            label2.Size = new Size(51, 21);
            label2.TabIndex = 1;
            label2.Text = "Maçã";
            // 
            // Btn_Voltar
            // 
            Btn_Voltar.BackColor = Color.White;
            Btn_Voltar.FlatAppearance.BorderSize = 0;
            Btn_Voltar.FlatStyle = FlatStyle.Flat;
            Btn_Voltar.ForeColor = Color.Transparent;
            Btn_Voltar.Location = new Point(0, 0);
            Btn_Voltar.Margin = new Padding(3, 4, 3, 4);
            Btn_Voltar.Name = "Btn_Voltar";
            Btn_Voltar.Size = new Size(46, 53);
            Btn_Voltar.TabIndex = 13;
            Btn_Voltar.UseVisualStyleBackColor = false;
            Btn_Voltar.Click += Btn_Voltar_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.PaleGreen;
            panel2.Controls.Add(Panel_Banana);
            panel2.Controls.Add(button4);
            panel2.Controls.Add(label8);
            panel2.Controls.Add(button5);
            panel2.Controls.Add(button6);
            panel2.Controls.Add(label9);
            panel2.Controls.Add(label10);
            panel2.Controls.Add(label11);
            panel2.Controls.Add(label12);
            panel2.Controls.Add(label13);
            panel2.Dock = DockStyle.Bottom;
            panel2.Location = new Point(0, 657);
            panel2.Margin = new Padding(3, 4, 3, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(545, 123);
            panel2.TabIndex = 17;
            // 
            // Panel_Banana
            // 
            Panel_Banana.Location = new Point(15, 49);
            Panel_Banana.Name = "Panel_Banana";
            Panel_Banana.Size = new Size(67, 67);
            Panel_Banana.TabIndex = 14;
            // 
            // button4
            // 
            button4.Font = new Font("Montserrat SemiBold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.Location = new Point(479, 33);
            button4.Margin = new Padding(3, 4, 3, 4);
            button4.Name = "button4";
            button4.Size = new Size(72, 53);
            button4.TabIndex = 16;
            button4.Text = "ADD";
            button4.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Montserrat SemiBold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(403, 49);
            label8.Name = "label8";
            label8.Size = new Size(21, 24);
            label8.TabIndex = 15;
            label8.Text = "0";
            // 
            // button5
            // 
            button5.Font = new Font("Montserrat SemiBold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button5.Location = new Point(431, 45);
            button5.Margin = new Padding(3, 4, 3, 4);
            button5.Name = "button5";
            button5.Size = new Size(26, 31);
            button5.TabIndex = 14;
            button5.Text = "+";
            button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.Font = new Font("Montserrat SemiBold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button6.Location = new Point(371, 45);
            button6.Margin = new Padding(3, 4, 3, 4);
            button6.Name = "button6";
            button6.Size = new Size(26, 31);
            button6.TabIndex = 13;
            button6.Text = "-";
            button6.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Montserrat SemiBold", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(227, 49);
            label9.Name = "label9";
            label9.Size = new Size(118, 37);
            label9.TabIndex = 5;
            label9.Text = "R$ 2,50";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Montserrat SemiBold", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.Location = new Point(226, 13);
            label10.Name = "label10";
            label10.Size = new Size(120, 21);
            label10.TabIndex = 4;
            label10.Text = "Preço Unitário";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Montserrat SemiBold", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.Location = new Point(121, 49);
            label11.Name = "label11";
            label11.Size = new Size(51, 37);
            label11.TabIndex = 3;
            label11.Text = "50";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Montserrat SemiBold", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.Location = new Point(102, 13);
            label12.Name = "label12";
            label12.Size = new Size(100, 21);
            label12.TabIndex = 2;
            label12.Text = "Quantidade";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Montserrat SemiBold", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.Location = new Point(16, 13);
            label13.Name = "label13";
            label13.Size = new Size(68, 21);
            label13.TabIndex = 1;
            label13.Text = "Banana";
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(192, 255, 192);
            panel3.Controls.Add(Panel_Morango);
            panel3.Controls.Add(button8);
            panel3.Controls.Add(label14);
            panel3.Controls.Add(button9);
            panel3.Controls.Add(button10);
            panel3.Controls.Add(label15);
            panel3.Controls.Add(label16);
            panel3.Controls.Add(label17);
            panel3.Controls.Add(label18);
            panel3.Controls.Add(label19);
            panel3.Dock = DockStyle.Bottom;
            panel3.Location = new Point(0, 534);
            panel3.Margin = new Padding(3, 4, 3, 4);
            panel3.Name = "panel3";
            panel3.Size = new Size(545, 123);
            panel3.TabIndex = 17;
            // 
            // Panel_Morango
            // 
            Panel_Morango.Location = new Point(16, 49);
            Panel_Morango.Name = "Panel_Morango";
            Panel_Morango.Size = new Size(67, 67);
            Panel_Morango.TabIndex = 14;
            // 
            // button8
            // 
            button8.Font = new Font("Montserrat SemiBold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button8.Location = new Point(479, 33);
            button8.Margin = new Padding(3, 4, 3, 4);
            button8.Name = "button8";
            button8.Size = new Size(72, 53);
            button8.TabIndex = 16;
            button8.Text = "ADD";
            button8.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Montserrat SemiBold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label14.Location = new Point(403, 49);
            label14.Name = "label14";
            label14.Size = new Size(21, 24);
            label14.TabIndex = 15;
            label14.Text = "0";
            // 
            // button9
            // 
            button9.Font = new Font("Montserrat SemiBold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button9.Location = new Point(431, 45);
            button9.Margin = new Padding(3, 4, 3, 4);
            button9.Name = "button9";
            button9.Size = new Size(26, 31);
            button9.TabIndex = 14;
            button9.Text = "+";
            button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            button10.Font = new Font("Montserrat SemiBold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button10.Location = new Point(371, 45);
            button10.Margin = new Padding(3, 4, 3, 4);
            button10.Name = "button10";
            button10.Size = new Size(26, 31);
            button10.TabIndex = 13;
            button10.Text = "-";
            button10.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Montserrat SemiBold", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label15.Location = new Point(227, 49);
            label15.Name = "label15";
            label15.Size = new Size(118, 37);
            label15.TabIndex = 5;
            label15.Text = "R$ 2,50";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Montserrat SemiBold", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label16.Location = new Point(226, 13);
            label16.Name = "label16";
            label16.Size = new Size(120, 21);
            label16.TabIndex = 4;
            label16.Text = "Preço Unitário";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Montserrat SemiBold", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label17.Location = new Point(121, 49);
            label17.Name = "label17";
            label17.Size = new Size(51, 37);
            label17.TabIndex = 3;
            label17.Text = "50";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Montserrat SemiBold", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label18.Location = new Point(102, 13);
            label18.Name = "label18";
            label18.Size = new Size(100, 21);
            label18.TabIndex = 2;
            label18.Text = "Quantidade";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Montserrat SemiBold", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label19.Location = new Point(13, 13);
            label19.Name = "label19";
            label19.Size = new Size(78, 21);
            label19.TabIndex = 1;
            label19.Text = "Morango";
            // 
            // panel4
            // 
            panel4.BackColor = Color.PaleGreen;
            panel4.Controls.Add(Panel_Abacaxi);
            panel4.Controls.Add(button12);
            panel4.Controls.Add(label20);
            panel4.Controls.Add(button13);
            panel4.Controls.Add(button14);
            panel4.Controls.Add(label21);
            panel4.Controls.Add(label22);
            panel4.Controls.Add(label23);
            panel4.Controls.Add(label24);
            panel4.Controls.Add(label25);
            panel4.Dock = DockStyle.Bottom;
            panel4.Location = new Point(0, 411);
            panel4.Margin = new Padding(3, 4, 3, 4);
            panel4.Name = "panel4";
            panel4.Size = new Size(545, 123);
            panel4.TabIndex = 18;
            // 
            // Panel_Abacaxi
            // 
            Panel_Abacaxi.Location = new Point(15, 49);
            Panel_Abacaxi.Name = "Panel_Abacaxi";
            Panel_Abacaxi.Size = new Size(67, 67);
            Panel_Abacaxi.TabIndex = 14;
            // 
            // button12
            // 
            button12.Font = new Font("Montserrat SemiBold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button12.Location = new Point(479, 33);
            button12.Margin = new Padding(3, 4, 3, 4);
            button12.Name = "button12";
            button12.Size = new Size(72, 53);
            button12.TabIndex = 16;
            button12.Text = "ADD";
            button12.UseVisualStyleBackColor = true;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Montserrat SemiBold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label20.Location = new Point(403, 49);
            label20.Name = "label20";
            label20.Size = new Size(21, 24);
            label20.TabIndex = 15;
            label20.Text = "0";
            // 
            // button13
            // 
            button13.Font = new Font("Montserrat SemiBold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button13.Location = new Point(431, 45);
            button13.Margin = new Padding(3, 4, 3, 4);
            button13.Name = "button13";
            button13.Size = new Size(26, 31);
            button13.TabIndex = 14;
            button13.Text = "+";
            button13.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            button14.Font = new Font("Montserrat SemiBold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button14.Location = new Point(371, 45);
            button14.Margin = new Padding(3, 4, 3, 4);
            button14.Name = "button14";
            button14.Size = new Size(26, 31);
            button14.TabIndex = 13;
            button14.Text = "-";
            button14.UseVisualStyleBackColor = true;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Montserrat SemiBold", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label21.Location = new Point(227, 49);
            label21.Name = "label21";
            label21.Size = new Size(118, 37);
            label21.TabIndex = 5;
            label21.Text = "R$ 2,50";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Font = new Font("Montserrat SemiBold", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label22.Location = new Point(226, 13);
            label22.Name = "label22";
            label22.Size = new Size(120, 21);
            label22.TabIndex = 4;
            label22.Text = "Preço Unitário";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Font = new Font("Montserrat SemiBold", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label23.Location = new Point(121, 49);
            label23.Name = "label23";
            label23.Size = new Size(51, 37);
            label23.TabIndex = 3;
            label23.Text = "50";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Font = new Font("Montserrat SemiBold", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label24.Location = new Point(102, 13);
            label24.Name = "label24";
            label24.Size = new Size(100, 21);
            label24.TabIndex = 2;
            label24.Text = "Quantidade";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Font = new Font("Montserrat SemiBold", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label25.Location = new Point(14, 13);
            label25.Name = "label25";
            label25.Size = new Size(71, 21);
            label25.TabIndex = 1;
            label25.Text = "Abacaxi";
            // 
            // panel5
            // 
            panel5.BackColor = Color.PaleGreen;
            panel5.Controls.Add(Panel_Laranja);
            panel5.Controls.Add(button16);
            panel5.Controls.Add(Label_LaranjaPreco);
            panel5.Controls.Add(Btn_AumentarLaranja);
            panel5.Controls.Add(Btn_DiminuirLaranja);
            panel5.Controls.Add(label27);
            panel5.Controls.Add(label28);
            panel5.Controls.Add(label29);
            panel5.Controls.Add(label30);
            panel5.Controls.Add(label31);
            panel5.Dock = DockStyle.Bottom;
            panel5.Location = new Point(0, 165);
            panel5.Margin = new Padding(3, 4, 3, 4);
            panel5.Name = "panel5";
            panel5.Size = new Size(545, 123);
            panel5.TabIndex = 20;
            // 
            // Panel_Laranja
            // 
            Panel_Laranja.Location = new Point(14, 49);
            Panel_Laranja.Name = "Panel_Laranja";
            Panel_Laranja.Size = new Size(67, 67);
            Panel_Laranja.TabIndex = 13;
            // 
            // button16
            // 
            button16.Font = new Font("Montserrat SemiBold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button16.Location = new Point(479, 33);
            button16.Margin = new Padding(3, 4, 3, 4);
            button16.Name = "button16";
            button16.Size = new Size(72, 53);
            button16.TabIndex = 16;
            button16.Text = "ADD";
            button16.UseVisualStyleBackColor = true;
            // 
            // Label_LaranjaPreco
            // 
            Label_LaranjaPreco.AutoSize = true;
            Label_LaranjaPreco.Font = new Font("Montserrat SemiBold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Label_LaranjaPreco.Location = new Point(403, 49);
            Label_LaranjaPreco.Name = "Label_LaranjaPreco";
            Label_LaranjaPreco.Size = new Size(21, 24);
            Label_LaranjaPreco.TabIndex = 15;
            Label_LaranjaPreco.Text = "0";
            Label_LaranjaPreco.TextChanged += Label_LaranjaPreco_TextChanged;
            // 
            // Btn_AumentarLaranja
            // 
            Btn_AumentarLaranja.Font = new Font("Montserrat SemiBold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_AumentarLaranja.Location = new Point(431, 45);
            Btn_AumentarLaranja.Margin = new Padding(3, 4, 3, 4);
            Btn_AumentarLaranja.Name = "Btn_AumentarLaranja";
            Btn_AumentarLaranja.Size = new Size(26, 31);
            Btn_AumentarLaranja.TabIndex = 14;
            Btn_AumentarLaranja.Text = "+";
            Btn_AumentarLaranja.UseVisualStyleBackColor = true;
            Btn_AumentarLaranja.Click += Btn_AumentarLaranja_Click;
            // 
            // Btn_DiminuirLaranja
            // 
            Btn_DiminuirLaranja.Enabled = false;
            Btn_DiminuirLaranja.Font = new Font("Montserrat SemiBold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_DiminuirLaranja.Location = new Point(371, 45);
            Btn_DiminuirLaranja.Margin = new Padding(3, 4, 3, 4);
            Btn_DiminuirLaranja.Name = "Btn_DiminuirLaranja";
            Btn_DiminuirLaranja.Size = new Size(26, 31);
            Btn_DiminuirLaranja.TabIndex = 13;
            Btn_DiminuirLaranja.Text = "-";
            Btn_DiminuirLaranja.UseVisualStyleBackColor = true;
            Btn_DiminuirLaranja.Click += Btn_DiminuirLaranja_Click;
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Font = new Font("Montserrat SemiBold", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label27.Location = new Point(227, 49);
            label27.Name = "label27";
            label27.Size = new Size(118, 37);
            label27.TabIndex = 5;
            label27.Text = "R$ 2,50";
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Font = new Font("Montserrat SemiBold", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label28.Location = new Point(226, 13);
            label28.Name = "label28";
            label28.Size = new Size(120, 21);
            label28.TabIndex = 4;
            label28.Text = "Preço Unitário";
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Font = new Font("Montserrat SemiBold", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label29.Location = new Point(121, 49);
            label29.Name = "label29";
            label29.Size = new Size(51, 37);
            label29.TabIndex = 3;
            label29.Text = "50";
            // 
            // label30
            // 
            label30.AutoSize = true;
            label30.Font = new Font("Montserrat SemiBold", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label30.Location = new Point(102, 13);
            label30.Name = "label30";
            label30.Size = new Size(100, 21);
            label30.TabIndex = 2;
            label30.Text = "Quantidade";
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.Font = new Font("Montserrat SemiBold", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label31.Location = new Point(16, 13);
            label31.Name = "label31";
            label31.Size = new Size(65, 21);
            label31.TabIndex = 1;
            label31.Text = "Laranja";
            // 
            // panel6
            // 
            panel6.BackColor = Color.FromArgb(192, 255, 192);
            panel6.Controls.Add(Panel_Uva);
            panel6.Controls.Add(button20);
            panel6.Controls.Add(label32);
            panel6.Controls.Add(button21);
            panel6.Controls.Add(button22);
            panel6.Controls.Add(label33);
            panel6.Controls.Add(label34);
            panel6.Controls.Add(label35);
            panel6.Controls.Add(label36);
            panel6.Controls.Add(label37);
            panel6.Dock = DockStyle.Bottom;
            panel6.Location = new Point(0, 288);
            panel6.Margin = new Padding(3, 4, 3, 4);
            panel6.Name = "panel6";
            panel6.Size = new Size(545, 123);
            panel6.TabIndex = 19;
            // 
            // Panel_Uva
            // 
            Panel_Uva.Location = new Point(15, 49);
            Panel_Uva.Name = "Panel_Uva";
            Panel_Uva.Size = new Size(67, 67);
            Panel_Uva.TabIndex = 14;
            // 
            // button20
            // 
            button20.Font = new Font("Montserrat SemiBold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button20.Location = new Point(479, 33);
            button20.Margin = new Padding(3, 4, 3, 4);
            button20.Name = "button20";
            button20.Size = new Size(72, 53);
            button20.TabIndex = 16;
            button20.Text = "ADD";
            button20.UseVisualStyleBackColor = true;
            // 
            // label32
            // 
            label32.AutoSize = true;
            label32.Font = new Font("Montserrat SemiBold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label32.Location = new Point(403, 49);
            label32.Name = "label32";
            label32.Size = new Size(21, 24);
            label32.TabIndex = 15;
            label32.Text = "0";
            // 
            // button21
            // 
            button21.Font = new Font("Montserrat SemiBold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button21.Location = new Point(431, 45);
            button21.Margin = new Padding(3, 4, 3, 4);
            button21.Name = "button21";
            button21.Size = new Size(26, 31);
            button21.TabIndex = 14;
            button21.Text = "+";
            button21.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            button22.Font = new Font("Montserrat SemiBold", 9.749999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button22.Location = new Point(371, 45);
            button22.Margin = new Padding(3, 4, 3, 4);
            button22.Name = "button22";
            button22.Size = new Size(26, 31);
            button22.TabIndex = 13;
            button22.Text = "-";
            button22.UseVisualStyleBackColor = true;
            // 
            // label33
            // 
            label33.AutoSize = true;
            label33.Font = new Font("Montserrat SemiBold", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label33.Location = new Point(227, 49);
            label33.Name = "label33";
            label33.Size = new Size(118, 37);
            label33.TabIndex = 5;
            label33.Text = "R$ 2,50";
            // 
            // label34
            // 
            label34.AutoSize = true;
            label34.Font = new Font("Montserrat SemiBold", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label34.Location = new Point(226, 13);
            label34.Name = "label34";
            label34.Size = new Size(120, 21);
            label34.TabIndex = 4;
            label34.Text = "Preço Unitário";
            // 
            // label35
            // 
            label35.AutoSize = true;
            label35.Font = new Font("Montserrat SemiBold", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label35.Location = new Point(121, 49);
            label35.Name = "label35";
            label35.Size = new Size(51, 37);
            label35.TabIndex = 3;
            label35.Text = "50";
            // 
            // label36
            // 
            label36.AutoSize = true;
            label36.Font = new Font("Montserrat SemiBold", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label36.Location = new Point(102, 13);
            label36.Name = "label36";
            label36.Size = new Size(100, 21);
            label36.TabIndex = 2;
            label36.Text = "Quantidade";
            // 
            // label37
            // 
            label37.AutoSize = true;
            label37.Font = new Font("Montserrat SemiBold", 8.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label37.Location = new Point(27, 13);
            label37.Name = "label37";
            label37.Size = new Size(40, 21);
            label37.TabIndex = 1;
            label37.Text = "Uva";
            // 
            // panel7
            // 
            panel7.Controls.Add(label1);
            panel7.Dock = DockStyle.Bottom;
            panel7.Location = new Point(0, 53);
            panel7.Name = "panel7";
            panel7.Size = new Size(545, 112);
            panel7.TabIndex = 21;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom;
            label1.AutoSize = true;
            label1.Font = new Font("Montserrat SemiBold", 21.7499962F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ImeMode = ImeMode.NoControl;
            label1.Location = new Point(200, 31);
            label1.Name = "label1";
            label1.Size = new Size(144, 51);
            label1.TabIndex = 12;
            label1.Text = "Frutas";
            // 
            // Frutas_UC
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoScroll = true;
            BackColor = Color.White;
            Controls.Add(panel7);
            Controls.Add(panel5);
            Controls.Add(panel6);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(Btn_Voltar);
            Controls.Add(panel1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Frutas_UC";
            Size = new Size(545, 824);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Panel panel1;
        private Label label5;
        private Label label6;
        private Label label4;
        private Label label3;
        private Label label2;
        private Button button1;
        private Button button3;
        private Label label7;
        private Button button2;
        private Button Btn_Voltar;
        private Panel panel2;
        private Button button4;
        private Label label8;
        private Button button5;
        private Button button6;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Panel panel3;
        private Button button8;
        private Label label14;
        private Button button9;
        private Button button10;
        private Label label15;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private Panel panel4;
        private Button button12;
        private Label label20;
        private Button button13;
        private Button button14;
        private Label label21;
        private Label label22;
        private Label label23;
        private Label label24;
        private Label label25;
        private Panel panel5;
        private Button button16;
        private Label Label_LaranjaPreco;
        private Button Btn_AumentarLaranja;
        private Button Btn_DiminuirLaranja;
        private Label label27;
        private Label label28;
        private Label label29;
        private Label label30;
        private Label label31;
        private Panel panel6;
        private Button button20;
        private Label label32;
        private Button button21;
        private Button button22;
        private Label label33;
        private Label label34;
        private Label label35;
        private Label label36;
        private Label label37;
        private Panel panel7;
        private Label label1;
        private Panel Panel_Laranja;
        private Panel Panel_Maca;
        private Panel Panel_Banana;
        private Panel Panel_Morango;
        private Panel Panel_Abacaxi;
        private Panel Panel_Uva;
    }
}
